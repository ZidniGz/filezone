

global.fs = require('fs');
global.path = require("path");
global.os = require("os");
global.jimp = require('jimp');
const Logger = require('@ptkdev/logger');
global.log = new Logger();
global.chalk = require('chalk');
global.FormData = new require("form-data")();
global.FileType = require("file-type");

global.util = require("util");
global.moment = require("moment");
global.speed = require('performance-now');
global.cron = require("node-cron");



global.color = (text, color) => {return !color ? chalk.green(text) : color.startsWith('#') ? chalk.hex(color)(text) : color.toLowerCase().includes("bright") ? chalk[color](util.format(text)) : chalk.keyword(color)(util.format(text));};

global.bgColor = function (text, color) {return !color ? chalk.bgGreen(text) : color.startsWith('#') ? chalk.bgHex(color)(text) : color.toLowerCase().includes("bright") ? chalk[color](util.format(text)) : chalk.bgKeyword(color)(util.format(text));}
	
global.uptime = (seconds) => {seconds = Number(seconds);var d = Math.floor(seconds / 86400000);var h = Math.floor((seconds / 3600000) % 24);var m = Math.floor((seconds / 60000) % 60);var s = Math.floor((seconds / 1000) % 60);var dDisplay = d > 0 ? d + (d == 1 ? " hari, " : " Hari, ") : "";var hDisplay = h > 0 ? h + (h == 1 ? " jam, " : " Jam, ") : "";var mDisplay = m > 0 ? m + (m == 1 ? " menit, " : " Menit, ") : "";var sDisplay = s > 0 ? s + (s == 1 ? " detik" : " Detik") : "";return dDisplay + hDisplay + mDisplay + sDisplay;}
global.runtime = (seconds) => {seconds = Number(seconds);var d = Math.floor(seconds / (3600 * 24));var h = Math.floor((seconds % (3600 * 24)) / 3600);var m = Math.floor((seconds % 3600) / 60);var s = Math.floor(seconds % 60); var dDisplay = d > 0 ? d + (d == 1 ? " hari, " : " Hari, ") : "";var hDisplay = h > 0 ? h + (h == 1 ? " jam, " : " Jam, ") : "";var mDisplay = m > 0 ? m + (m == 1 ? " menit, " : " Menit, ") : "";var sDisplay = s > 0 ? s + (s == 1 ? " detik" : " Detik") : "";return dDisplay + hDisplay + mDisplay + sDisplay;}

global.monospace = (ktl) => {return "```" + ktl + "```";}

global.axios = require("axios");
global.fetch = require('node-fetch');
global.got = require('got');
global.request = require("request");
global.cheerio = require("cheerio");


global.config = {
  owner : ['6281215205433'],
  prefix: new RegExp("^[" + "!#%&?/;:,.~".replace(/[|\\{}()[\]^$*?.^]/g, "\\$&") + "]"),
  pairingNumber: "62882007340755",
  Email: "zidnialazmi@gmail.com",
  Website: "https://zidni.me",
  limit: { limitUser: 30, gameLimitUser: 10, gameLimitPremium: 30 }
 }

const { Database, Limit, Premium, User, Saweria } = require('./lib')
global.db = new Database();



global.regex = {
     tiktok:  /^(?:https?:\/\/)?(?:www\.|vt\.|vm\.|t\.)?(?:tiktok\.com\/)(?:\S+)?$/,
     youtube: /(?:http(?:s|):\/\/|)(?:(?:www\.|)youtube(?:\-nocookie|)\.com\/(?:watch\?.*(?:|\&)v=|embed|shorts\/|v\/)|youtu\.be\/)([-_0-9A-Za-z]{11})/g,
     instagram: /(?:https?:\/\/)?(?:www\.)?(?:instagram\.com\/(?:stories|s|p|reel|tv)\/([\w-]+))/g,
     cocofun: /https?:\/\/(?:www\.)?icocofun\.com\/share\/post\/\d+\?lang=\w+&pkg=\w+&share_to=\w+&m=[\w-]+&d=[\w-]+&nt=\d+/g     
    }


const { isLimit, limitAdd, getLimit, giveLimit, addBalance, kurangBalance, getBalance, isGame, gameAdd, givegame, cekGLimit } = Limit
const { addPay, expiredPay, expiredPremiumPay, getDateId, clearAllUser, resetLevelingXp, userXp, userLeveling, getLevelingXp, getLevelingLevel, getLevelingId, addLevelingXp, addLevelingLevel, addUserId } = User
global.expiredPremiumPay=expiredPremiumPay;global.expiredPay=expiredPay;global.addPay=addPay;global.getDateId=getDateId;global.clearAllUser=clearAllUser;global.resetLevelingXp=resetLevelingXp;global.userXp=userXp;global.userLeveling=userLeveling;global.getLevelingXp=getLevelingXp;global.getLevelingLevel=getLevelingLevel;global.getLevelingId=getLevelingId;global.addLevelingXp=addLevelingXp;global.addLevelingLevel=addLevelingLevel;global.addUserId=addUserId
global.isLimit=isLimit,global.limitAdd=limitAdd,global.getLimit=getLimit,global.giveLimit=giveLimit,global.addBalance=addBalance,global.kurangBalance=kurangBalance,global.getBalance=getBalance,global.isGame=isGame,global.gameAdd=gameAdd,global.givegame=givegame,global.cekGLimit=cekGLimit;
global.pmPay=JSON.parse(fs.readFileSync('./database/payment.json'));global.tebakanime=JSON.parse(fs.readFileSync('./lib/src/tebakanime.json'));global.user = JSON.parse(fs.readFileSync('./database/user.json')),global.limit=JSON.parse(fs.readFileSync("./database/limit.json")),global.glimit=JSON.parse(fs.readFileSync("./database/glimit.json")),global.balance=JSON.parse(fs.readFileSync("./database/balance.json")),global.premium=JSON.parse(fs.readFileSync("./database/premium.json"))
global.prem = Premium;


const { sizeFormatter } = require("human-readable");
global.Size = sizeFormatter({
	std: "JEDEC",
	decimalPlaces: "2",
	keepTrailingZeroes: false,
	render: (literal, symbol) => `${literal} ${symbol}B`,
});


global.math = global.math ? global.math : {}; 	
global.family = global.family ? global.family : {};
global.anime = global.anime ? global.anime : {};
global.tictactoe = global.tictactoe ? global.tictactoe : [];


global.Pay = new Saweria("fa673399-943f-46aa-a605-847840f68a3c");


let d = new Date
let locale = 'id'
let gmt = new Date(0).getTime() - new Date('1 Januari 2021').getTime()
global.weton = ['Pahing', 'Pon','Wage','Kliwon','Legi'][Math.floor(((d * 1) + gmt) / 84600000) % 5]
global.week = d.toLocaleDateString(locale, { weekday: 'long' })
global.calender = d.toLocaleDateString(locale, {day: 'numeric',month: 'long',year: 'numeric'})
          

global.response = {
	wait: "Tunggu Sebentar!",
	error: {
		Iv: "Link yang Kamu berikan tidak valid",
		api: "Maaf terjadi kesalahan"
	},
	OnlyGrup: "Perintah ini hanya dapat digunakan didalam Grup",
	OnlyPM: "Perintah ini hanya dapat digunakan di private message",
	GrupAdmin: "Perintah ini hanya dapat digunakan oleh Admin Grup",
	BotAdmin: "Bot Harus menjadi admin",
	OnlyOwner: "This command can only be used by the bot owner",
	OnlyPrem: "Perintah ini hanya untuk member premium"
}

