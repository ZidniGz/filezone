require('./config');
const cooldown = new Map();
const { Correct } = require('./lib');
const { correct } = Correct

const isUrl = (url) => {
	return url.match(
		new RegExp(
			/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/,
			"gi"
		)
	);
};


module.exports = async function (zaa, z, store, commands) {
  try {
        if (z.fromMe) return;
        if (z.body.startsWith(">= ")  && z.isOwner) {try {let evale = await eval(`;(async () => { ${z.body.slice(2)} })()`);if (typeof evale !== 'string') evale = util.inspect(evale);z.reply(`${evale}`);} catch (e) {z.reply(util.format(e));}} else if (z.body.startsWith("$ ") && z.isOwner) {require('child_process').exec(z.body.slice(2), (err, stdout) => {if (err) return z.reply(`${err}`);if (stdout) z.reply(`${stdout}`);})} else if (z.body.startsWith("> ") && z.isOwner && !z.fromMe) { try { let evaled = await eval(z.body.slice(2));if (typeof evaled !== 'string') evaled = util.inspect(evaled);z.reply(`${evaled}`); } catch (err) {z.reply(`${err}`);}} else if (z.body.startsWith('< ') && z.isOwner && !z.fromMe){try { let evaled = await eval(`${z.body.slice(2)}+''`); if (typeof evaled !== 'string') evaled = util.inspect(evaled);z.reply(z.body.slice(2) + " = " + evaled)} catch (err) {z.reply(`${err}`)}}		
		
      
		global.gcount = z.isPremium ? config.limit.gameLimitPremium : config.limit.gameLimitUser;
		global.limitCount = config.limit.limitUser;		
		
		const userLevel = getLevelingLevel(z.sender, user);
        const userExp = getLevelingXp(z.sender, user);
        const userId = getLevelingId(z.sender, user);
        const amountExp = Math.floor(Math.random() * 10) + 50;
        const requiredExp = 1000 * userLevel;
        const userPersen = userExp/requiredExp*100;
        const userVerified = getDateId(z.sender, user);
     	
		const contentQ = z.quoted ? JSON.stringify(z.quoted) : [];
		const isQAudio = z.type === "extendedTextMessage" && contentQ.includes("audioMessage");
		const isQVideo = z.type === "extendedTextMessage" && contentQ.includes("videoMessage");
		const isQImage = z.type === "extendedTextMessage" && contentQ.includes("imageMessage");
		const isQDocument = z.type === "extendedTextMessage" && contentQ.includes("documentMessage");
		const isQSticker = z.type === "extendedTextMessage" && contentQ.includes("stickerMessage");
	    const Media = (media = {}) => {list = [];if (media.isQAudio) {list.push("audioMessage");};if (media.isQVideo) {list.push("videoMessage");};if (media.isQImage) {list.push("imageMessage");};if (media.isQDocument) {list.push("documentMessage");};if (media.isQSticker) {list.push("stickerMessage");};return list;};
        
        global.dashboard = JSON.parse(fs.readFileSync("./database/dashboard.json"));	
 		const cmdName = z.command;
		const cmd = commands.get(z.body.trim().split(/ +/).shift().toLowerCase()) || [...commands.values()].find((x) => x.alias.find((x) => x.toLowerCase() == z.body.trim().split(/ +/).shift().toLowerCase())) || commands.get(cmdName) || [...commands.values()].find((x) => x.alias.find((x) => x.toLowerCase() == cmdName));		
		          
				
		 cmd
			? console.log(color("[ CMD ]", "redBright"), bgColor(z.sender.split("@")[0], "lime"), color(`( ${z.pushName} )`, "blueBright"), z.body, (z.isGroup ? color("in " + z.metadata.subject, "aqua") : ''))
			: console.log(color("[ MSG ]", "redBright"), bgColor(z.sender.split("@")[0], "lime"), color(`( ${z.pushName} )`, "blueBright"), z.body,  (z.isGroup ? color("in " + z.metadata.subject, "aqua") : ''));
	
       if (!cooldown.has(z.sender)) {
			cooldown.set(z.sender, new Map());
		}
		
		//Leveling
		if (z.isCmd) {try {if (userLevel === undefined && userId === undefined)addUserId(calender, z.pushName, z.sender, user);if (z.isCmd){addLevelingXp(z.sender, amountExp, user);addBalance(z.sender, Math.floor(Math.random() * 20), balance);if (userExp >= requiredExp) {addLevelingLevel(z.sender, 1, user);resetLevelingXp(z.sender, userExp, user);if(userLevel >= 25){let anuitu =`${userLevel}`;var sapi = zaa.randomNomor(math(anuitu));giveLimit(z.sender, sapi, limit);} else {var sapi = "0";};if(userLevel >= 50){var nana = zaa.randomNomor(24) + "h";prem.addPremiumUser(z.sender, nana, premium);} else {var nana = "0";};let levelnih = userLevel + 1;let required = 1000 * levelnih;let siji = userExp - requiredExp;let Persen = siji/required*100;let persenya =`${Persen}`;let teks = `乂  *L E V E L - U P*\n\n	◦  *Nama :* @${z.sender.split('@')[0]}\n	◦  *Limit :* ${getLimit(z.sender, limit)}\n	◦  *Level :* ${userLevel} -> ${levelnih}\n	◦  *Pangkat :* ${userLeveling(levelnih)}\n	◦  *Exp :*  ${userXp(Persen)} ${persenya.split(".")[0]}%\n\n`;await z.reply(teks);};}} catch (err) {console.error(err)}}


         if (!z.body.includes("return") && !z.isCmd && !z.body.startsWith('> ')) {
         
    if (regex.tiktok instanceof RegExp && regex.tiktok.test(z.quoted ? z.quoted.body : z.body)) {
        if (isLimit(z.sender, z.isPremium, z.isOwner, limit) && !z.fromMe) return z.reply(`Your limit has run out, please send ${z.prefix}limit to check the limit`);const extract = (z.quoted && z.quoted.body) ? generateLink(z.quoted.body) : z.body ? generateLink(z.body) : null; if (extract) {const links = extract.filter(v => ttFixed(v).match(regex.tiktok));
            if (links.length != 0) {
                z.reply(response.wait);const json = await tiktok(ttFixed(links[0]));if (json.status === 'error') return z.reply(`Error! private videos or videos not available.`); let caption = json.result.description;if (json.result.type === 'video') {let buffer = await got(json.result.video[0]).buffer();let audio = await toAudio(buffer);zaa.sendMessage(z.from, { audio, mimetype: 'audio/mpeg' }, { quoted: z });return zaa.sendMessage(z.from, { video: buffer, caption }, { quoted: z });  };if (json.result.type === 'image') {for (let p of json.result.images) {zaa.sendMessage(z.from, { image: { url: p }, caption }, { quoted: z });};};limitAdd(z.sender, z.isOwner, limit);
            }
        }
    } else if (regex.instagram instanceof RegExp && regex.instagram.test(z.quoted ? z.quoted.body : z.body)) {
    if (isLimit(z.sender, z.isPremium, z.isOwner, limit) && !z.fromMe) return z.reply(`Your limit has run out, please send ${z.prefix}limit to check the limit`);const extract = (z.quoted && z.quoted.body) ? generateLink(z.quoted.body) : z.body ? generateLink(z.body) : null;if (extract) {const links = extract.filter(v => igFixed(v).match(regex.instagram));
        if (links.length != 0) {
            z.reply(response.wait);
            await instagram(igFixed(links[0])).then(data => {
                for (let i of data) {if (i.type === "video") {zaa.sendMessage(z.from, { caption: `Instagram Download`, video: { url: i.url } }, { quoted: z });} else if (i.type === "image") {zaa.sendMessage(z.from, { caption: `Instagram Download`, image: { url: i.url } }, { quoted: z });}};limitAdd(z.sender, z.isOwner, limit);
            }).catch(() => z.reply(`Error! private videos or videos not available.`));
            
        }
    }
         } else if (regex.cocofun instanceof RegExp && regex.cocofun.test(z.quoted ? z.quoted.body : z.body)) {
            if (isLimit(z.sender, z.isPremium, z.isOwner, limit) && !z.fromMe) return z.reply(`Your limit has run out, please send ${z.prefix}limit to check the limit`);const extract = (z.quoted && z.quoted.body) ? generateLink(z.quoted.body) : z.body ? generateLink(z.body) : null; if (extract) {const links = extract.filter(v => v.match(regex.cocofun));
        if (links.length != 0) {z.reply(response.wait);await cocofun(links[0]).then(data => {z.sendFile(z.from, data.url, '', data.title);limitAdd(z.sender, z.isOwner, limit);
            }).catch(() => z.reply(`Error! private videos or videos not available.`));            
        }
    }
     } else if (regex.youtube instanceof RegExp && regex.youtube.test(z.quoted ? z.quoted.body : z.body)) {
    if (isLimit(z.sender, z.isPremium, z.isOwner, limit) && !z.fromMe) return z.reply(`Your limit has run out, please send ${z.prefix}limit to check the limit`);const extract = (z.quoted && z.quoted.body) ? generateLink(z.quoted.body) : z.body ? generateLink(z.body) : null;if (extract) {const links = extract.filter(v => v.match(regex.youtube));
        if (links.length != 0) {
            z.reply(response.wait);
            await youtube(links[0]).then(async (data) => {
                if (!(z.quoted ? z.quoted.body.endsWith('--mp3') : z.body.endsWith('--mp3'))) {let video = await data.video.auto.download();let buff = await got(video, { referer: 'https://www.y2mate.com' }).buffer();if (buff.length > 30000000) return z.reply('has passed the delivery limit!!');let quo = await z.reply(`*YOUTUBE DOWNLOAD*\n\n*Title :* ${data.title}\n*Quality :* auto\n*Durasi :* ${data.duration}\n*Size :* ${Size(buff.length)}\n\n_Media sedang Dikirimkan..._`);zaa.sendMessage(z.from, { video: buff }, { quoted: quo });} else if (z.quoted ? z.quoted.body.endsWith('--mp3') : z.body.endsWith('--mp3')) {let video = await data.audio['128kbps'].download();let buff = await got(video, { referer: 'https://www.y2mate.com' }).buffer();if (buff.length > 30000000) return z.reply('has passed the delivery limit!!');let quo = await z.reply(`*YOUTUBE DOWNLOAD*\n\n*Title :* ${data.title}\n*Quality :* ${data.audio['128kbps'].quality}\n*Durasi :* ${data.duration}\n*Size :* ${data.audio['128kbps'].fileSizeH}\n\n_Media sedang Dikirimkan..._`);zaa.sendMessage(z.from, { audio: buff, mimetype: 'audio/mpeg' }, { quoted: quo });};limitAdd(z.sender, z.isOwner, limit);
            }).catch(() => z.reply(`Error! private videos or videos not available.`));            
        }
    }
}
     }

      

         //Detect Spam
		const now = Date.now();const timestamps = cooldown.get(z.sender);const cdAmount = 5 * 1000;if (timestamps.has(z.sender) && z.isCmd && !z.isPremium) {const expiration = timestamps.get(z.sender) + cdAmount;if (now < expiration) {let timeLeft = (expiration - now) / 1000;if (z.isGroup) {log.debug('Spamming');return await z.reply(`This group is on cooldown, please wait another _${timeLeft.toFixed(1)} second(s)_`);} else if (!z.isGroup) {log.debug('Spamming');return await z.reply(`You are on cooldown, please wait another _${timeLeft.toFixed(1)} second(s)_`);}}}
		
		
		setTimeout(() => timestamps.delete(z.sender), cdAmount);
		
		
		if (z.isCmd && !cmd) {
		var array = Array.from(commands.keys());Array.from(commands.values()).map((v) => v.alias).join(" ").replace(/ +/gi, ",").split(",").map((v) => array.push(v));
		var anu = correct(cmdName, array);
		var alias = commands.get(anu.result) || Array.from(commands.values()).find((v) => v.alias.find((x) => x.toLowerCase() == anu.result)) || "";
		teks = `Command Not Found!\nMaybe you mean is\n\n*Command :* ${z.prefix+anu.result}\n${ /[a-zA-Z]|[0-9]/.test(alias.alias) ? `*Alias :* ${alias.alias.join(", ")}\n` : ''}*Accuracy :* ${anu.rating.toFixed(2)}\n\n_Send command again if needed_`;if (anu.rating !== 0)  z.reply(teks);} 
            
          	if (Array.from(commands.func.values()).filter((v) => v.options.isFunction)) 
          	{ Array.from(commands.func.values()).filter((v) => v.options.isFunction).forEach(async function(r) {
          	      await r.exec({ zaa, z, store })
	            }
	             )
	        }
            				
		if (!cmd) return 
		const cmdOptions = cmd.options;
		if (cmdOptions.noPrefix) {
			if (z.isCmd) return;
			z.q = z.body.split(" ").splice(1).join(" ");
		} else if (!cmdOptions.noPrefix) {
			if (!z.isCmd) return;
		}
	      if (cmdOptions?.isSpam) {
			timestamps.set(z.sender, now);
		}
		
		   		
		
	if (cmd && cmd.category != "private") {
			let comand = dashboard.find((command) => command.name == cmd.name);
			if (comand) {
				comand.success += 1;
				comand.lastUpdate = Date.now();
				fs.writeFileSync("./database/dashboard.json", JSON.stringify(dashboard));
			} else {
				await db.modified("dashboard", { name: cmd.name, success: 1, failed: 0, lastUpdate: Date.now() });
			}
		}   		
		
		if (cmdOptions?.isPremium && !z.isPremium) {
			await zaa.sendMessage(z.from, { text: response.OnlyPrem }, { quoted: z });
			return true;
		}
		if (cmdOptions.query && !z.q) {
			await z.reply(
				typeof cmdOptions.query == "boolean" && cmdOptions.query ? `Masukan query` : cmdOptions.query
				      .replace('%prefix', z.prefix)
				        .replace('%cmd', z.command)
			);
			return true;
		}		
		if (cmdOptions.isLimit && !z.isPremium) {
			if (isLimit(z.sender, z.isPremium, z.isOwner, limit) && !z.fromMe)
				return z.reply(`Your limit has run out, please send ${z.prefix}limit to check the limit`);
			limitAdd(z.sender, z.isOwner, limit);       
		}
		if (cmdOptions.isLimitGame) {
			if (isGame(z.sender, z.isOwner, gcount, glimit) && !z.fromMe)
				return z.reply(`Your game limit has run out`);
			gameAdd(z.sender, glimit, z.isOwner);
		}
		if (cmdOptions.isAdmin && !z?.isAdmin) {
			await zaa.sendMessage(z.from, { text: response.GrupAdmin }, { quoted: z });
			return true;
		}
		if (cmdOptions.isQuoted && !z.quoted) {
			await z.reply(`Please reply message`);
			return true;
		}
		if (cmdOptions.isMedia) {
			let medianya = Media(cmdOptions.isMedia ? cmdOptions.isMedia : {});
			if (typeof medianya[0] != "undefined" && !medianya.includes(z.quoted ? z.quoted.type : []))
				return z.reply(
					`Please reply *${medianya
						.map((a) => `${((aa = a.charAt(0).toUpperCase()), aa + a.slice(1).replace(/message/gi, ""))}`)
						.join("/")}*`
				);
		}
		if (cmdOptions.isOwner && !z.isOwner && !z.fromMe) {
			await zaa.sendMessage(z.from, { text: response.OnlyOwner }, { quoted: z });
			return true;
		}
		if (cmdOptions.isGroup && !z.isGroup) {
			await zaa.sendMessage(z.from, { text: response.OnlyGrup }, { quoted: z });
			return true;
		}
		if (cmdOptions.isBotAdmin && !z?.isBotAdmin) {
			await zaa.sendMessage(z.from, { text: response.BotAdmin }, { quoted: z });
			return true;
		}
		if (cmdOptions.isPrivate && !z.from.endsWith("@s.whatsapp.net")) {
			await zaa.sendMessage(z.from, { text: response.OnlyPM }, { quoted: z });
			return true;
		}
		if (cmdOptions.isUrl && !isUrl(z.quoted ? z.quoted.q : z.q ? z.q : "p")) {
			await zaa.sendMessage(z.from, { text: response.error.Iv }, { quoted: z });
			return true;
		}
		if (cmdOptions.wait) {
			await zaa.sendMessage(
				z.from,
				{ text: typeof cmdOptions.wait == "string" ? cmdOptions.wait : response.wait },
				{ quoted: z }
			);
		}
		
		try {
	  
			await cmd.exec({ zaa, z,
                command: cmd.name,
                commands,
                store             
            })
               
		} catch (e) {
		        
			let fail = dashboard.find((command) => command.name == z.command);
			  if (fail && cmd.category != "private") {
			    fail.failed += 1;
				fail.success -= 1;
				fail.lastUpdate = Date.now();
				fs.writeFileSync("./database/dashboard.json", JSON.stringify(dashboard));		
	     } else {
				await db.modified("dashboard", { name: cmd.name, success: 0, failed: 1, lastUpdate: Date.now() });
			}
			await z.reply('error occurred');
			await z.reply(util.format(e), {from:owner[0]+'@s.whatsapp.net'});
	
		}
	
 
		
		
          
 } catch (e) {
    log.error(e.stack)
			}
}
		