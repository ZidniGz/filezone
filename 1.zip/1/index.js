require('./config');
const { 
 default: Connect,
 delay,
 useMultiFileAuthState,
 DisconnectReason, 
 jidNormalizedUser, 
 makeInMemoryStore,
 makeCacheableSignalKeyStore,
 PHONENUMBER_MCC
  } = require('baileys');
  
const { Boom } = require ('@hapi/boom');

const pairingCode = !!config.pairingNumber || process.argv.includes("--pairing-code")
const useMobile = process.argv.includes("--mobile")
const store = makeInMemoryStore({ logger: require('pino')({ level: "fatal" }).child({ level: "fatal" }) })

const { Collection, Client, Serialize, parseOptions, Scandir} = require("./lib");
const pluginFilter = filename => /\.js$/.test(filename);
const Commands = new Map();
Commands.func = new Map();
Commands.lockcmd = new Map();
const Spinnies = require("spinnies");
global.spinnies = new Spinnies({
    color: 'blue', succeedColor: 'green',
	spinner : { 
      interval: 200,
		frames: ["∙∙∙", "●∙∙", "∙●∙", "∙∙●", "∙∙∙"]
	 },
});


	
global.owner = config.owner;

const chatsData = cron.schedule(
	"*/10 * * * *", // 10 minutes per delete
	() => {
		try {
			fs.rmSync(path.join(__dirname, "database", "mess.json"));
			db.addDatabase("mess", "[]");
			log.info("Delete Database Chat, Cache Temp");
			file = fs.readdirSync("./temp").map((a) => "./temp/" + a);
			file.map((a) => fs.unlinkSync(a));
		} catch (e) {
			console.log(e);
}
	},
	{ scheduled: true, timezone: "Asia/Jakarta" }
);


const readFunction = () => {
      for (let res of Scandir(path.join(__dirname, "./lib/function")).filter(pluginFilter)) {        
         require(res)()
         nocache(res, file => console.log(`File "${file}" has updated!`));    
         }
      }
      
      
const readCommands = () => {
      let dir = path.join(__dirname, "./command");
      let listCommand = {}    
    try {
        for (let res of Scandir(dir).filter(pluginFilter)) {
           let groups = path.basename(res, '.js');
           listCommand[groups] = [];
                const command = require(res);
                if (typeof command.exec != "function") continue;
                listCommand[groups].push(command);
                const cmdOptions = {
				    name: "command",
				    alias: [""],
				    desc: "",
				    use: "",
				    cooldown: 5,
			     	type: "", 
				    category: typeof command.category == "undefined" ? "" : res.toLowerCase(),
				    isFunction: false,
				    wait: false,
				    isOwner: false,
				    isAdmin: false,
				    isQuoted: false,
			    	isGroup: false,
			    	isBotAdmin: false,
				    query: false,
				    isPrivate: false,
				    isLimit: false,
				    isLimitGame: false,
			     	isSpam: false,
			    	noPrefix: false,
				isMedia: {
					isQVideo: false,
					isQAudio: false,
					isQImage: false,
					isQSticker: false,
					isQDocument: false,
				    },
			    	isPremium: false,
			    	disable: false,
			    	isUrl: false,
				    exec: () => {},
			};
			let cmd = parseOptions(cmdOptions, command);
			let options = {};
		     	for (var k in cmd) typeof cmd[k] == "boolean" ? (options[k] = cmd[k]) : k == "query" || k == "isMedia" ? (options[k] = cmd[k]) : "";
			let cmdObject = {
				name: cmd.name,
				alias: cmd.alias,
				desc: cmd.desc,
				use: cmd.use,
				type: cmd.type,
				category: cmd.category,
			
				options: options,
				exec: cmd.exec,
			        };			    
                if (!cmd.isFunction) { Commands.set(command.name, cmdObject) } else if (cmd.isFunction) { Commands.func.set(cmd.isFunction ? command.event : undefined,cmdObject) }
                nocache(res, file => console.log(`File "${file}" has updated!`)); 
        }
        Commands.list = listCommand;
       
    } catch (e) {
        console.error(e)
    }
}


const start = async function () {
   process.on("unhandledRejection", (err) => console.error(err));      
      await chatsData.start();
      nocache('./lib/Simple', file => console.log(`File "${file}" has updated!`));
      nocache('./handler', file => console.log(`File "${file}" has updated!`));                                           
     const { state, saveCreds } = await useMultiFileAuthState(`./sessions`);

   const options = {
      printQRInTerminal: !pairingCode, // popping up QR in terminal log     
      mobile: useMobile,
      auth: {
         creds: state.creds,
         keys: makeCacheableSignalKeyStore(state.keys, require('pino')({ level: "fatal" }).child({ level: "fatal" })),
      },
      browser: ['Chrome (Linux)', '', ''], // for this issues https://github.com/WhiskeySockets/Baileys/issues/328
      markOnlineOnConnect: true, // set false for offline
      generateHighQualityLinkPreview: true,
      logger: require('pino')({ level: "silent" })
       // make high preview 
       }
       
        var zaa = Connect(options);
   
  if (pairingCode && !zaa.authState.creds.registered) {
      if (useMobile) throw new Error('Cannot use pairing code with mobile api')

      let phoneNumber
      if (!!config.pairingNumber) {
         phoneNumber = config.pairingNumber.replace(/[^0-9]/g, '')

         if (!Object.keys(PHONENUMBER_MCC).some(v => phoneNumber.startsWith(v))) {
            console.log("Start with your country's WhatsApp code, Example : 62xxx")
            process.exit(0)
         }
      } 
      
      setTimeout(async () => {
         let code = await zaa.requestPairingCode(phoneNumber)
         code = code?.match(/.{1,4}/g)?.join("-") || code
         console.log(chalk.black(chalk.bgGreen(`Your Pairing Code : `)), chalk.black(chalk.white(code)))
      }, 3000)
   }
   
      zaa.ev.on("creds.update", saveCreds);
      
      store.bind(zaa.ev);      
      await Client({zaa, store});    
      
            
      //Premium expired
   await prem.expiredCheck(zaa, premium);
   await expiredPay(zaa, pmPay);
   await expiredPremiumPay(zaa, pmPay);
   
 
    zaa.ev.on("connection.update", async(update) => {
    
    const { lastDisconnect, connection } = update   
        if (connection == "open") {
            zaa.user = {
                id: zaa.user.id,
                jid: jidNormalizedUser(zaa.user.id),
                name: zaa.user.name
            };
        };
      
   if (connection) spinnies.add("spinner-2", { text: "Connecting to the WhatsApp bot...", color: "cyan" });
		if (connection == "connecting")
			spinnies.add("spinner-2", { text: "Connecting to the WhatsApp bot...", color: "cyan" });	
	     if (connection) {
			if (connection == "close")
				spinnies.fail("spinner-2", { text: "Connection: " + connection, color: "yellow" });
		}
		if (connection == "open")
			spinnies.succeed("spinner-2", { text: "Successfully connected to whatsapp", color: "green" });
       
        if (connection == "close") {
            const printf = msg => console.log(color('[SYS]', '#009FFF'), color(moment().format('DD/MM/YY HH:mm:ss'), '#A1FFCE'), color(msg, '#f64f59'));            
            let reason = new Boom(lastDisconnect?.error)?.output.statusCode
            if (reason === DisconnectReason.badSession) { printf(`Bad Session File, Please Delete Session and Scan Again`); zaa.logout(); }
            else if (reason === DisconnectReason.connectionClosed) { printf("Connection closed, reconnecting...."); start(); }
            else if (reason === DisconnectReason.connectionLost) { printf("Connection Lost from Server, reconnecting..."); start(); }
            else if (reason === DisconnectReason.connectionReplaced) { printf("Connection Replaced, Another New Session Opened, Please Close Current Session First"); zaa.logout(); }
            else if (reason === DisconnectReason.loggedOut) { printf(`Device Logged Out, Please Scan Again And Run.`); process.exit(); }
            else if (reason === DisconnectReason.restartRequired) { printf("Restart Required, Restarting..."); start(); }
            else if (reason === DisconnectReason.timedOut) { printf("Connection TimedOut, Reconnecting..."); start(); }
            else zaa.end(`Unknown DisconnectReason: ${reason}|${connection}`)
        }
    })
    
   zaa.ev.on("messages.upsert", async (chatUpdate) => {
        await readCommands();
          await readFunction();
    
        if (chatUpdate.type !== "notify") return;     
        let z = await Serialize(zaa, chatUpdate.messages[0]);
        if (!z.key) return;
       	if (z.key.id.startsWith("BAE5") && z.key.id.length === 16) return;
        if (Object.keys(z.message)[0] == "senderKeyDistributionMessage") delete z.message.senderKeyDistributionMessage;
		if (Object.keys(z.message)[0] == "messageContextInfo") delete z.message.messageContextInfo;
		
		let dataCek = db.cekDatabase("antidelete", "id", z.from);
		if (dataCek) zaa.addMessage(z, z.type);
    	if (z && z.type == "protocolMessage") zaa.ev.emit("message.delete", z.message.protocolMessage.key);    	
            
        require('./handler')(zaa, z, store, Commands);
    })
    
    zaa.ev.on("call", async (json) => {      
         for (const id of json) {
            if (id.status === "offer") {
               let msg = await zaa.sendMessage(id.from, {
                  text: `Maaf untuk saat ini, Kami tidak dapat menerima panggilan, entah dalam group atau pribadi\n\nJika Membutuhkan bantuan ataupun request fitur silahkan chat owner :p`,
                  mentions: [id.from],
               })
               zaa.sendContact(id.from, owner, msg)
               await zaa.rejectCall(id.id, id.from)
            };
         }      
   })
   
   zaa.ev.on("message.delete", async (m) => {
		if (!m) m = {};
		let data2 = db.cekDatabase("antidelete", "id", m.remoteJid || "");
		if (typeof data2 != "object") return;
		const dataChat = JSON.parse(fs.readFileSync("./database/mess.json"));
		let mess = dataChat.find((a) => a.id == m.id);
		if (!mess) return;
		let mek = mess.msg		
		if (mek.key.id.startsWith("BAE5") && mek.key.id.length === 16) return;
		let participant = mek.key.remoteJid.endsWith("@g.us")
			? zaa.decodeJid(mek.key.participant)
			: zaa.decodeJid(mek.key.remoteJid);
		let froms = mek.key.remoteJid;
		await zaa.sendMessage(
			froms,
			{
				text:`\n 「 Anti Delete Message 」\n\n*• Participant:* ${participant.split("@")[0]}\n*• Delete message:* ${moment(
						Date.now()
					).format("dddd, DD/MM/YYYY HH:mm:ss")}\n*• Message send:* ${moment(
						mek.timestamp * 1000
					).format("dddd, DD/MM/YYYY HH:mm:ss")}\n*• Type:* ${Object.keys(mek.message)[0]}\n`,
				mentions: [participant],
			},
			{ quoted: mek }
		);
		await zaa.relayMessage(froms, mek.message, { messageId: mek.key.id });
	});
	
   zaa.ev.on("presence.update", async (up) => {
    if (!up) return
      const { id, presences } = up
      const afk = JSON.parse(fs.readFileSync("./database/afk.json"));                      
   if (id.endsWith('g.us')) {
      for (let jid in presences) {
         if (!presences[jid] || jid == zaa.decodeJid(zaa.user.id)) continue
         if ((presences[jid].lastKnownPresence === 'composing' || presences[jid].lastKnownPresence === 'recording') && afk[jid] != undefined) {
             const afktime = await uptime(Date.now() - afk[jid].time)
            const afkreason = afk[jid].reason;
			text = `@${jid.split("@")[0]} telah kembali dari afk, dia sedang ${presences[jid].lastKnownPresence === "composing" ? "mengetik" : "merekam"}\nSetelah *${afkreason}*, Sejak ${afktime}`
			zaa.sendMessage(id, {text, mentions:[jid]})
			delete afk[jid];
			await fs.writeFileSync("./database/afk.json", JSON.stringify(afk));
        
         }
      }
   } else {}
      })
   
   }
   
   
function nocache(module, cb = () => {}) {
    fs.watchFile(require.resolve(module), async () => {
        await uncache(require.resolve(module))
        cb(module)
    })
};

function uncache(module = '.') {
    return new Promise((resolve, reject) => {
        try {
            delete require.cache[require.resolve(module)]
            resolve()
        } catch (e) {
            reject(e)
        }
    })
};
	   
   
   
start()