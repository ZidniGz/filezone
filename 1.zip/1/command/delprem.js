const fs = require("fs");
module.exports = {
	name: "delpremium",
	alias: ["delprem", "delvip"],
	category: "private",
	use: "@tag / nomor",
	query: "Penggunaan :\n*#delprem* @tag\n*#delprem* nomor",
	isSpam: true,
	isOwner: true,
	async exec({ z }) {
	
	  if (z?.quoted) {
	  	premium.splice(prem.getPremiumPosition(z.quoted.sender, premium), 1);
			fs.writeFileSync("./database/premium.json", JSON.stringify(premium));
			z.reply("sukses");
	  } else 
  	if (z.mentions.length !== 0) {
			for (let i = 0; i < z.mentions.length; i++) {
				premium.splice(prem.getPremiumPosition(z.mentions[i], premium), 1);
				fs.writeFileSync("./database/premium.json", JSON.stringify(premium));
			}
			z.reply("Sukses");
		} else if (z.args.length > 1) {
			premium.splice(prem.getPremiumPosition(args[0] + "@s.whatsapp.net", premium), 1);
			fs.writeFileSync("./database/premium.json", JSON.stringify(premium));
			z.reply("sukses");
		} else z.reply('False');
	},
}