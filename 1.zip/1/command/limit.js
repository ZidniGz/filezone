module.exports = {
	name: "limit",
	alias: ["cekglimit", "ceklimit", "glimit"],
	category: "bank",
	desc: "check limit",
	isSpam: true,
	async exec({ z }) {
		prefix = z.prefix
	if (z.mentions.length !== 0) {			
				let teks = `Statistic @${z.mentions[0].split('@')[0]}\n\n`;
				    teks += `Limit : ${prem.checkPremiumUser(z.mentions[0], premium) ? "Unlimited" : `${getLimit(z.mentions[0], limit)}/${limitCount}`}\n`.monospace();
				    teks += `Limit Game : ${cekGLimit(z.mentions[0], gcount, glimit)}/${gcount}\n`.monospace();
				    teks += `Balance : $${getBalance(z.mentions[0],balance)}`.monospace();
				    teks += `\n\nYou can buy limit with *${prefix}buylimit* and *${prefix}buyglimit* to buy game limit`
			     z.reply(teks);
		} else {			
				let teks =`Statistic @${z.sender.split('@')[0]}\n\n`;
				  teks += `Limit : ${z.isPremium ? "Unlimited" : `${getLimit(z.sender, limit)}/${limitCount}`}\n`.monospace();
				  teks += `Limit Game : ${cekGLimit(z.sender, gcount, glimit)}/${gcount}\n`.monospace();
				  teks += `Balance : $${getBalance(z.sender,balance)}`.monospace();
				  teks += `\n\nYou can buy limit with *${prefix}buylimit* and *${prefix}buyglimit* to buy game limit`;
				  z.reply(teks);	
		}
	},
};
