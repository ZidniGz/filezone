module.exports = {
	name: "stats",
	alias: ["status","os"],
	category: "info",
	desc: "Bot status",
	isSpam: true,
	wait: true,
	async exec({ z }) {
		let text = "";
		text += `HOST:\n • Os : ${os.type()}\n • Arch : ${os.arch()}\n • Release : ${os.release()}\n`;
		text += ` • Memory : ${Size(os.totalmem() - os.freemem())} / ${Size(os.totalmem())}\n`;
		text += ` • Uptime : ${toTime(os.uptime())}\n • Platform : ${os.platform()}`;
		await z.reply(text);
	},
};
