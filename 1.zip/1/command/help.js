const hari = moment.tz('Asia/Jakarta').format("a");
const ucapanWaktu = hari.charAt(0).toUpperCase() + hari.slice(1);
const processTime = (timestamp, now) => {return moment.duration(now - moment(timestamp * 1000)).asSeconds();};
const toFirstCase = (str) =>{let first = str.split(" ").map(nama => nama.charAt(0).toUpperCase() + nama.slice(1)).join(" ");return first;}
const monospace = (ktl) => {return "```" + ktl + "```";}
const p = '```';
const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)



module.exports = {
	name: "help",
	alias: ["h", "cmd", "menu"],
	category: "main",
	isSpam: true,
	async exec({ zaa, z, commands }) {
		if (z.q) {
					const name = z.q.toLowerCase();
			const cmd = commands.get(name) || [...commands.values()].find((x) => x.alias.find((x) => x == z.args[0])) || [...commands.values()].find((x) => x.name === z.args[0])
			if (!cmd || (cmd.category === "private" && !owner.includes(z.sender.split('@')[0])))
				return await z.reply("Command not found");
			helpcmd = "*Helper Command*\n\n"
			helpcmd += monospace(` × Command : ${z.q}`) + "\n"
			helpcmd += monospace(` × Triger Command : ${cmd.alias.join(", ")}`) + "\n"
			helpcmd += monospace(` × Category : ${cmd.category}`) + "\n\n"
			helpcmd += "*Command Atribute*\n"
			helpcmd += monospace(` × isOwner : ${cmd.options.isOwner ? '✅' : '❌'}`) + "\n"
			helpcmd += monospace(` × isAdmin : ${cmd.options.isAdmin ? '✅' : '❌'}`) + "\n"
			helpcmd += monospace(` × isPremium : ${cmd.options.isPremium ? '✅' : '❌'}`) + "\n"
			helpcmd += monospace(` × isLimit : ${cmd.options.isLimit ? cmd.options.isLimit : cmd.options.isLimitGame ? '✅' : '❌'}`) + "\n"
			helpcmd += monospace(` × isBotAdmin : ${cmd.options.isBotAdmin ? '✅' : '❌'}`) + "\n"
			helpcmd += monospace(` × isGroup : ${cmd.options.isGroup ? '✅' : '❌'}`) + "\n"
                        helpcmd += monospace(` × isPrivate : ${cmd.options.isPrivate ? '✅' : '❌'}`) + "\n"
			helpcmd += monospace(` × Command Lock : ${commands.lockcmd.get(z.q) ? "✅" : "❌"}`) + "\n\n"
			helpcmd += "*Command Description*\n"
			helpcmd += monospace(` × Deskripsi : ${cmd.desc}`) + "\n"
			helpcmd += monospace(` × Usage : ${z.prefix}${cmd.name} ${cmd.use}`) + "\n\n"
	           return z.reply(helpcmd)
		} else {
			const { pushName, sender } = z;
		    const cmds = commands.keys();
			let category = [];
			const xes = uptime2(prem.getPremiumExpired(z.sender, premium) - Date.now());
			dashboard = dashboard.sort(function (a, b) {
				return b.success - a.success;
			});

			for (let cmd of cmds) {
				let info = commands.get(cmd);
				if (!cmd) continue;
			    cteg = info.category || "No Category";
				if (info.type == "changelog") continue;
				if (cteg == "hidden") continue;
				if (cteg == "private") continue;
				if (!cteg || cteg === "private") cteg = "owner command";
				if (Object.keys(category).includes(cteg)) category[cteg].push(info);
				else {
					category[cteg] = [];
					category[cteg].push(info);
				}
			}
			let a = new Date;
			let str = `◪ *INFO USER*
			
❏ Nomer: 「  ${z.sender.split("@")[0]} 」
❏ Nama: 「  ${z.pushName} 」
❏ Status: 「 ${z.isPremium ? "Premium" : z.isOwner ? "Owner" : "Standar"} 」
${z.isPremium ? `❏ Expired: 「 ${xes} 」\n` : ""}
${readMore}
◪ *Fitur terpopuler saat ini*
${
	dashboard[0]
		? `1. *${z.prefix}${dashboard[0].name}* was used *${dashboard[0].success + dashboard[0].failed}* times`
		: ``
}
${
	dashboard[1]
		? `2. *${z.prefix}${dashboard[1].name}* was used *${dashboard[1].success + dashboard[1].failed}* times`
		: ``
}
${
	dashboard[2]
		? `3. *${z.prefix}${dashboard[2].name}* was used *${dashboard[2].success + dashboard[2].failed}* times\n\n`
		: ``
}\n`;
			const keys = Object.keys(category);
			//var a = 1
			for (const key of keys) {
				str += `*❏ ${toFirstCase(key)}*\n${category[key]
					.map(
						(cmd, index) =>
							`*${index + 1}.* ${p}${cmd.options.noPrefix ? "" : "#"}${cmd.name}${p} ${
								cmd.category == "private"
									? ""
									: cmd.use
									? cmd.use.replace(">", " 」").replace("<", "「 ")
									: ""
							}`
					)
					.join("\n")}\n\n`;
			}
		    str += `${readMore} *𝑆𝑖𝑚𝑝𝑙𝑒 𝐵𝑜𝑡 𝑊ℎ𝑎𝑡𝑠𝐴𝑝𝑝 ッ*`;
		    z.reply(str,{adReply:true, large: false });
		}
	},
};
