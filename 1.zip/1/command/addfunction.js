const fs = require("fs");
module.exports = {
	name: "addfunction",
	alias: ["addfunc"],
	category: "private",
	isOwner: true,
	async exec({ z }) {
	
	  if (z?.quoted) {
	  if (!z.args[0]) return z.reply("Name of file?");
	  let format = `module.exports = async () => { ${z.quoted.body} }`
	  fs.writeFileSync("./lib/function/"+z.args[0], format);
			z.reply("sukses");
	  } else 
  	if (z.args[0] && !z.quoted) {
  	  if (!z.args[0]) return z.reply('Name of file?');
  	  let [siji, loro] = z.q.split('•')
  	  let format = `module.exports = async () => { ${loro} }`
		fs.writeFileSync("./lib/function/"+siji, format);
			z.reply("sukses");
		} else z.reply('Gagal');
	},
};
