module.exports = {
	name: "runtime",
	alias: ['uptime'],
	category: "info",
	type: "changelog",
	desc: "mengecek waktu hidup bot",
	isSpam: true,
	async exec({ z }) {
		await z.reply(runtime(process.uptime()));
	},
};
