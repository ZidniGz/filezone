module.exports = {
   name: 'revoke',
   alias:['revoke'],
   category: 'group',
   isAdmin: true,
   isBotAdmin: true,
   isGroup: true,
     async exec({zaa, z}) {
    let res = await zaa.groupRevokeInvite(z.from)
    let grup = await zaa.groupInviteCode(z.from);
    await z.reply( 'https://chat.whatsapp.com/' + grup, {adReply: true, url: `https://chat.whatsapp.com/${grup}`, title: z.metadata.subject})
}
    }