module.exports = {
	name: "promote",
	alias: ["pm","promote"],
	category: "group",
	desc: "Promote jadi admin group",
	use: "<tag/reply>",
	isGroup: true,
	isBotAdmin: true,
	isAdmin: true,
	async exec({ z, zaa }) {
		const mm = z.mentions;
		for (let i of mm) await zaa.groupParticipantsUpdate(z.from, [i], "promote");
		await z.reply("Suksess");
	},
};
