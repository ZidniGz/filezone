module.exports = {
  name: "play",
  alias: ["play"],
  category: "search",
  use: "<query>",
  query: true,
  wait: true,
  isLimit: true,
  async exec({zaa, z}){
  const data = await ytMusic(z.quoted ? z.quoted.q : z.q)
  if (!data) return z.reply(`Musik Tidak Ditemukan!!`)
  const { url, title, author, timestamp, image } = data.getRandom();
    const { audio } = await youtube(url)
   const txt = `*YOUTUBE DOWNLOAD*\n\n*Title :* ${title}\n*Artist :* ${author.name}\n*Durasi :* ${timestamp}\n*Size :* ${audio['128kbps'].fileSizeH}\n\n_Media sedang Dikirimkan..._`
   let quo = await z.reply(txt, {image, adReply: true, title, url, large: true})
   let buffer = await got(await audio['128kbps'].download(), {referer: "https://y2mate.com"}).buffer()
   zaa.sendMessage(z.from, {audio: buffer, mimetype : 'audio/mpeg' },{quoted :quo})
  }
}
