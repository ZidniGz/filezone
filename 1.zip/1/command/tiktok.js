
module.exports = {
  name: "tiktok",
  alias: ["tiktok","tiktoknowm","tiktokwm","tiktokmp3","donlodtt"],
  category: "downloader",
  query: "need url",
  use: "<url>",
  wait:true,
  isUrl: true,
  isLimit: true,
  async exec({z, zaa}){
    const extract = (z.quoted && z.quoted.q) ? generateLink(z.quoted.q) : z.q ? generateLink(z.q) : null
         if (extract) {
            const links = extract.filter(v => ttFixed(v).match(regex.tiktok))
              if (links.length != 0) {
              const json = await tiktok(ttFixed(links[0]))                 
                  if (json.status === 'error') return z.reply(`Error! private videos or videos not available.`)
                     let caption = json.result.description;
                     if (json.result.type === 'video') {
                          let buffer = await got(json.result.video[0]).buffer()
                          let audio = await toAudio(buffer)                    
                         zaa.sendMessage(z.from, {audio, mimetype: 'audio/mpeg'},{quoted: z})
                         return zaa.sendMessage(z.from, {video: buffer, caption},{quoted:z});
                        }
                     if (json.result.type === 'image') {
                        for (let p of json.result.images) {
                           zaa.sendMessage(z.from, {image:{url:p},caption},{quoted:z})                      
                        }
                     }                 
             }
           }
  }
}