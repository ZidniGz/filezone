module.exports = {
	name: "addpremium",
	alias: ["addprem", "addvip"],
	category: "private",
	desc: "Add user premium ke database",
	isSpam: true,
	isOwner: true,
	query: "Penggunaan :\n*#addprem* @tag waktu\n*#addprem* nomor waktu\n\nContoh : #addprem @tag 30d",
	use: "@tag 30d",
	async exec({ z }){
	
if (z?.quoted) {
	 prem.addPremiumUser(z.quoted.sender, z.args[0], premium);
			z.reply("Sukses");
	  }
	    else if (z.mentions.length !== 0) {
			for (let i = 0; i < z.mentions.length; i++) {
				prem.addPremiumUser(z.mentions[0], z.args[1], premium);
			}
			z.reply("Sukses");
		} else if (z.args.length > 0)  {
			prem.addPremiumUser(z.args[1] + "@s.whatsapp.net", z.args[1], premium);
			z.reply("Sukses");
		} else z.reply("False");
	},
};
