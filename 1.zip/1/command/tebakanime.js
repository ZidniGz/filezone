module.exports = {
	name: "tebakanime",
	alias: ["tebakanime"],
	category: "game",
	desc: "Menebak karakter anime",
	isSpam: true,
	isGroup: true,
	isLimitGame: true,
    async exec({zaa, z}) {
		  
        let timeout = 60000
                 let poin = 10
                 let id = z.from;
                    if (id in anime) return z.reply('Masih ada soal belum terjawab di chat ini')
                 let json = tebakanime.getRandom();
                 let teks = `*Game Tebak Anime*\n\n*Hint :* ${json.deskripsi}\n\nTimeout *60.00 detik*\n`.trim()
                    anime[id] = [await z.reply(teks, {image: json.img, adReply: true, url: json.img, title: json.jawaban.replace(/[b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z]/gi, 'ˍ'), large: true}),json, poin,4,
        setTimeout(() => {
                 if (anime[id]) z.reply(`*Time has run out*\n\n*Answer :* ${json.jawaban}`)
                     delete anime[id]}, timeout)]
                     
	},
}



           