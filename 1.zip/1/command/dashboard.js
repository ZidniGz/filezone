module.exports = {
	name: "dashboard",
	alias: ["db"],
	desc: "display bot dashboard info",
	category: "info",
	isSpam: true,
	wait: true,
	async exec({ z, commands }) {
	let p = '```'
		if (z.q) {
		    	var data  =
				[...commands.values()].find((a) => a.name == z.q.toLowerCase()) ||
				[...commands.values()].find((x) => x.alias.find((a) => a == z.q.toLowerCase()));
			if (!data) throw "Feature not found";
			let findData = dashboard.find((a) => a.name == data.name.toLowerCase());		
			teks = `${p} #${findData.name}${p} : ${findData.success + findData.failed}\n\n`;
			teks += `*• Success :* ${findData.success}\n`;
			teks += `*• Failed :* ${findData.failed}\n`;
			teks += `*• Last Used :* ${moment(findData.lastUpdate).format('DD/MM/YY HH:mm:ss')}\n\n`;
			await z.reply(teks, { adReply: true });
		} else {
			dashboard = dashboard.sort(function (a, b) {
				return b.success - a.success;
			});
			let success = dashboard.map((a) => a.success);
			let failed = dashboard.map((a) => a.failed);
			let jumlah = require("mathjs").evaluate(success.join("+")) + require("mathjs").evaluate(failed.join("+"));
			let teks = `*Dashboard*\n\n`;
			teks += `*Total Hit:* ${jumlah}\n`;
			teks += ` *-Success :* ${require("mathjs").evaluate(success.join("+"))}\n`;
			teks += ` *-Failed :* ${require("mathjs").evaluate(failed.join("+"))}\n\n`;
			teks += `*Most Command Global*\n\n`;
			let dbny = dashboard.length > 5 ? 5 : dashboard.length;
			for (let i = 0; i < dbny; i++) {
				teks += `${p}${i+1}. #${dashboard[i].name}${p} : ${dashboard[i].success + dashboard[i].failed}\n`;
				teks += `*• Success :* ${dashboard[i].success}\n`;
				teks += `*• Failed :* ${dashboard[i].failed}\n`;
				teks += `*• Last Used :* ${moment(dashboard[i].lastUpdate).format('DD/MM/YY HH:mm:ss')}\n\n`;
			}
			teks += `Type *${z.prefix}dashboard <name command>* to find out the command data.\nUsage: *${z.prefix}dashboard help*`;
			await z.reply(teks, { adReply: true });
		}
	},
};
