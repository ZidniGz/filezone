module.exports = {
	name: "buylimit",
	category: "bank",
	isSpam: true,
	use: "<amount>",
	query: "Send an order *#buylimit* the limit amount you want to buy\n\nPrice 1 limit = $300 balance",
	async exec({ z }){
		if (z.q.includes("-")) return z.reply(`Don't use -`)
		if (isNaN(z.q)) return z.reply(`Must be a number`)
		let ane = Number(Math.floor(z.q) * 300);
		if (getBalance(z.sender, balance) < ane) return z.reply(`Balance kamu tidak mencukupi untuk pembelian ini`)
		kurangBalance(z.sender, ane, balance);
		giveLimit(z.sender, Math.floor(z.q), limit);
		await z.reply(
			`The limit purchase of ${z.q} was successful\n\nRemaining Balance : $${getBalance(
				z.sender,
				balance
			)}\nRemaining Limit : ${getLimit(z.sender, limitCount, limit)}/${limitCount}`
		);
	},
};
