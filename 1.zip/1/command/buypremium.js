const p = '```'
module.exports = {
	name: "buyprem",
	alias: ["buypremium"],
	category: 'payment',
	desc: 'buy a premium package with a payment gateway',
	isSpam: true,
	async exec({ z }) {
        const itemName = z.args[0]
        const text = `乂  *P R E M I U M*\n\n${p}1. PREMIUM 1 DAY${p}\n◦  *Price* : Rp 2.000,00,-\n◦  *Command* : ${z.prefix+z.command} 1\n\n${p}2. PREMIUM 7 DAY${p}\n◦  *Price* : Rp 5.000,00,-\n◦  *Command* : ${z.prefix+z.command} 2\n\n${p}3. PREMIUM 30 DAY${p}\n◦  *Price* : Rp 10.000,00,-\n◦  *Command* : ${z.prefix+z.command} 3\n`
        if (!itemName) return z.reply(text, {adReply:true, large:false, title: 'Premium', image: 'https://telegra.ph/file/3e7146307bbf278a58224.jpg'})
          let price;
       if (itemName === '1') {
            price = 2000;
          } else if (itemName === '2') {
             price = 5000;
          } else if (itemName === '3') {
             price = 10000;
          } else return z.reply(text, {adReply:true, large:false, title: 'Premium', image: 'https://telegra.ph/file/3e7146307bbf278a58224.jpg'})
        const pending = pmPay.find(v => v.jid === z.sender && v.state === 'PENDING');
        const process = pmPay.find(v => v.jid === z.sender && v.state === 'PROCESS');
        
        if (pending) {
            return z.reply(`Selesaikan terlebih dahulu proses sebelumnya atau kirim *n* untuk membatalkan.`);
        } else if (process) return z.reply(`Selesaikan terlebih dahulu proses pembayaran sebelumnya.`);

        let teks = `Faktur “PREMIUM PLAN ${itemName}” dengan rincian sebagai berikut :\n\n`;
        teks += ` ◦ Nomor: ${require("libphonenumber-js").parsePhoneNumber('+' + z.sender.replace("@s.whatsapp.net", "")).format("INTERNATIONAL")}\n`.monospace();
        teks += ` ◦ Harga: Rp. ${formatter(price)},-\n`.monospace();
        teks += ` ◦ PPN: Rp. ${formatter(calculatePPN(price + 800))},-\n\n`.monospace();
        teks += `${p} ◦ Total:${p} *Rp. ${formatter(price + calculatePPN(price + 800))},-*\n\n`;
        teks += `Kirim *y* untuk melanjutkan proses pembayaran atau kirim *n* untuk membatalkan.`;

        z.reply(teks).then(() => {
        addPay(z.sender, price, calculatePPN(price + 800), 'PREMIUM PLAN '+itemName, pmPay)
               });
	},
};
