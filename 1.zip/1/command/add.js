module.exports = {
	name: "add",
	use: "<number/tag/reply>",
	category: "group",
	desc: "add members to group",
	wait: true,
	isGroup: true,
	isBotAdmin: true,
	isAdmin: true,
	isSpam: true,
	async exec({zaa, z}) {
     let _participants = z.metadata.participants.map(user => user.jid)
        let users = (await Promise.all(
            z.q.split(',')
            .map(v => v.replace(/[^0-9]/g, ''))
            .filter(v => v.length > 4 && v.length < 20 && !_participants.includes(v + '@s.whatsapp.net'))
            .map(async v => [
                v,
                await zaa.onWhatsApp(v + '@s.whatsapp.net')
            ])
        )).filter(v => v[1]).map(v => v[0] + '@c.us')
          await zaa.groupParticipantsUpdate(z.from, users, 'add').then(res => console.log(res)).catch(e => console.log(e))
     },
};
