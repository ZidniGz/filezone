module.exports = {
	name: "demote",
	alias: ["dm","demote"],
	category: "group",
	desc: "Demote admin group",
	use: "<tag/reply>",
	isGroup: true,
	isBotAdmin: true,
	isAdmin: true,
	async exec({ z, zaa }) {
		const mm = z.mentions
		for (let i of mm) await zaa.groupParticipantsUpdate(z.from, [i], "demote");
		await z.reply("Suksess");
	},
};
