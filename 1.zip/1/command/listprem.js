module.exports = {
	name: "listpremium",
	alias: ["listprem", "listvip"],
	category: "info",
	isSpam: true,
	async exec({zaa, z}) {
		let txt = `List Prem\nAmount : ${premium.length}\n\n`;
		if (premium[0]) {
			for (let i of premium) {
			txt += `*ID :* @${i.id.split("@")[0]}\n*Expired :* ${uptime(i.expired - Date.now())}\n\n`;
			}
		}
		z.reply(txt, true);
	},
};
