module.exports = {
	isFunction: true,
	event: 'buyprem',
	async exec({ z, zaa, store }) {
	     const pending = gateway = pmPay.find(v => v.jid === z.sender && v.state === 'PENDING');
        const process = pmPay.find(v => v.jid === z.sender && v.state === 'PROCESS');
            
	       
     if (pending) {
        let body = z.body.toLowerCase()
       if (body === 'y') {
            z.reply('Menghasilkan QR Code pembayaran...');
        const total = parseInt(gateway.amount) + parseInt(gateway.admin);
        const json = await Pay.createPayment(total, gateway.package);

        if (!json.status) return z.reply(`Terjadi kesalahan saat menghasilkan pembayaran:\n${json.msg}`);

        let teks = `乂  *Q R I S*\n\n`;
        teks += `”Lakukan pembayaran sebelum 5 menit”\n\n`;
        teks += `➠ ID: ${json.data.id}\n`.monospace();
        teks += `➠ Total: Rp. ${formatter(json.data.amount_raw)},-\n\n`.monospace();
        teks += `Catatan:\n`;
        teks += ` • Kode QR hanya berlaku untuk 1x transfer dan expired dalam 5 menit.\n`
        teks += ` • Setelah pembayaran, tunggu beberapa saat dan kamu akan menerima status pembayaran.\n`
        teks += ` • Jika pembayaran berhasil, maka otomatis akan di proses\n`
        teks += ` • Untuk bantuan lebih lanjut, hubungi *${z.prefix}owner*`

        z.sendFile(z.from, Buffer.from(json.data.qr_image.split(',')[1], 'base64'), 'qr.png', teks).then(() => {
            gateway.state = 'PROCESS';
            gateway.receipt = json.data.id;
            gateway.expired = json.data.expired;
            fs.writeFileSync('./database/payment.json', JSON.stringify(pmPay));
        });
       } else if (body === 'n'){
           if (!pending && !process) {
            return z.reply(`Pembelian berhasil dibatalkan.`);
        }

        z.reply(`Pembelian berhasil dibatalkan.`);
        if (pending) {
            pmPay = removeItem(pmPay, pending);
            fs.writeFileSync('./database/payment.json', JSON.stringify(pmPay));
        }
        if (process) {
            pmPay = removeItem(pmPay, process);
            fs.writeFileSync('./database/payment.json', JSON.stringify(pmPay));
        }
       }              
      }
	},
};
