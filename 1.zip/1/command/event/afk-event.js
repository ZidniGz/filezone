module.exports = {
	isFunction: true,
	event: 'afk',
	async exec({ z, zaa, store }) {
	  const afk = JSON.parse(fs.readFileSync("./database/afk.json"));
		  if (afk[z.sender] != undefined){
          const afkreason = afk[z.sender].reason;
			tek = `@${z.sender.split('@')[0]} telah kembali dari afk!\nSetelah *${afkreason}*, Sejak ${uptime(Date.now() - afk[z.sender].time)}`
			z.reply(tek);
			delete afk[z.sender];
			await fs.writeFileSync("./database/afk.json", JSON.stringify(afk));
  }
		if (z.mentions.length != 0 && afk[z.mentions[0]] != undefined) {
			const pushname = store.contacts[z.mentions[0]];
			const afktime = await uptime(Date.now() - afk[z.mentions[0]].time)
			const afkreason = afk[z.mentions[0]].reason;
			txt = `${pushname != undefined ? pushname.name : "he`s"} Jangan di Tag, Dia sedang afk!\n`
			txt += "Reason : " + afkreason + "\n"
			txt += "Sejak : " + afktime + "\n\n"
			txt += "Hubungi kembali setelah Dia kembali dari afk!!"
			await z.reply(txt);
		
	}
	},
};
