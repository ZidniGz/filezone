module.exports = {
	isFunction: true,
	event: 'family100',
	async exec({ z, zaa }) {
	   if (family) {
  
	   if(z.from in family){
                      let similarity = require('similarity')
                      let threshold = 0.72 // semakin tinggi nilai, semakin mirip
                      let id =  z.from
                      let room = family[id]
                      let text = z.body.toLowerCase().replace(/[^\w\s\-]+/, '')
                      let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(z.body.toLowerCase())
                          if (!isSurrender) {
                      let index = room.jawaban.indexOf(text)
                          if (index < 0) {
                      if (Math.max(...room.jawaban.filter((_, index) => !room.terjawab[index]).map(jawaban => similarity(jawaban,text))) >= threshold) return z.reply('Dikit lagi!')
                             }
                      if (!z.isCmd && room.terjawab[index]) {return} 
                           room.terjawab[index] = z.sender
                           addBalance(z.sender, room.winScore, balance)
                             }
                       let isWin = room.terjawab.length === room.terjawab.filter(v => v).length
                       let caption = `\n*Question :* ${room.soal}\n\nTerdapat *${room.jawaban.length}* jawaban${room.jawaban.find(v => v.includes(' ')) ? `\n(beberapa jawaban terdapat spasi)\n`: ''}\n${isWin ? `*SEMUA JAWABAN TERJAWAB*` : isSurrender ? '*MENYERAH!*' : ''}\n${Array.from(room.jawaban, (jawaban, index) => {
 return isSurrender || room.terjawab[index] ? `(${index + 1}) ${jawaban} ${room.terjawab[index] ? '@' + room.terjawab[index].split('@')[0] : ''}`.trim() : false}).filter(v => v).join('\n')}\n${isSurrender ? '' : `+$${room.winScore} tiap jawaban benar`}\n`.trim()

          z.reply(caption).then(msg => {
                  family[id].msg = msg}).catch(_ => _); if (isWin || isSurrender) delete family[id] 

}        }
	},
}