module.exports = {
	isFunction: true,
	event: 'tebakanime',
	async exec({ z, zaa }) {
  let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(z.body.toLowerCase())
  
	if (!isSurrender) {
	   if(!z.fromMe && z.from in anime){
               const similarity = require('similarity')
               const threshold = 0.72
               let id = z.from
               if (!(id in anime) && /^tebakanime/i.test(z.body)) return z.reply('soal itu sudah berakhir')                     
               let json = JSON.parse(JSON.stringify(anime[id][1]))
                  if (z.body.toLowerCase() == json.jawaban.toLowerCase().trim()) {
                       addBalance(z.sender, anime[id][2], balance)
	await z.reply(
						`*Congratulations your answer is correct!*\n\n*Answer :* ${json.jawaban} ( ${json.deskripsi} )\n*Present :* $200\n\nWant to play again? send *${z.prefix}tebakanime*`
				               	);clearTimeout(anime[id][4]);delete anime[id]
                       } else {
                 if (--anime[id][3] == 0) {
                         clearTimeout(anime[id][4]);
                         delete anime[id]
                              z.reply(`*Kesempatan habis!*\njawabannya adalah *${json.jawaban}*`)
                      } else if(similarity(z.body.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) z.reply(`*Hampir Benar...*`)
                else z.reply(`*Jawaban salah!*\nmasih ada ${anime[id][3]} kesempatan`)
}
   }
     } else if (isSurrender) {
        if(!z.fromMe && z.from in anime){
             let json = JSON.parse(JSON.stringify(anime[z.from][1]))                  
            z.reply(`*Answer :* ( ${json.jawaban} )  ( ${json.deskripsi} )`)
             clearTimeout(anime[z.from][4]);
             delete anime[z.from]
        }
    }

	},
}