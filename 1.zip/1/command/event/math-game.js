module.exports = {
	isFunction: true,
	event: 'math',
	async exec({ z, zaa }) {
  let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(z.body.toLowerCase())
  if (!isSurrender) {
	   if( z.from in math){
            try{
                        let id = z.from
                   if (!(id in math) && /^apa hasil dari/i.test(z.body)) return z.reply('soal itu sudah berakhir')
                       let math2 = JSON.parse(JSON.stringify(math[id][1]))
                    if (z.body == math2.result) {
                          addBalance(z.sender, math2.bonus, balance)
                          clearTimeout(math[id][3])
                          delete math[id]
          		await z.reply(
						`*Congratulations your answer is correct!*\n\n*Answer :* ${math2.result} ( ${math2.mode} )\n*Present :* $${math2.bonus}\n\nWant to play again? send *${z.prefix}math ${math2.mode}*`
				               	)
                    } else {    
                      if (--math[id][2] == 0) {
                           clearTimeout(math[id][3])
                           delete math[id]
                           z.reply(`*Kesempatan habis!*\nAnswer *${math2.result}*`)
                    } else z.reply(`*Jawaban salah!*\nmasih ada ${math[id][2]} kesempatan`)
                }
               
                       }catch(e){console.log(e)}}
} else if (isSurrender) {
         if( z.from in math){
    z.reply(`*Answer :* ( ${JSON.parse(JSON.stringify(math[z.from][1])).result} )  ( ${JSON.parse(JSON.stringify(math[z.from][1])).mode} )`)
    clearTimeout(math[z.from][3])
                           delete math[z.from]
 }
   }
  
	},}