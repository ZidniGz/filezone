	let modes = {noob: [-3, 3, -3, 3, '+-', 15000, 2],easy: [-10, 10, -10, 10, '*/+-', 20000, 6],medium: [-40, 40, -20, 20, '*/+-', 40000, 10],hard: [-100, 100, -70, 70, '*/+-', 60000, 20],extreme: [-999999, 999999, -999999, 999999, '*/', 99999, 30],impossible: [-99999999999, 99999999999, -99999999999, 999999999999, '*/', 30000, 40],impossible2: [-999999999999999, 999999999999999, -999, 999, '/', 30000, 50]}
       let operators = {'+': '+','-': '-','*': '×','/': '÷'}
             function genMath(mode) {let [a1, a2, b1, b2, ops, time, bonus] = modes[mode];let a = randomInt(a1, a2);let b = randomInt(b1, b2);let op = [...ops].getRandom();let result = (new Function(`return ${a} ${op.replace('/', '*')} ${b < 0 ? `(${b})` : b}`))();if (op == '/') [a, result] = [result, a];return {str: `${a} ${operators[op]} ${b}`,mode,time,bonus,result}}
function randomInt(from, to) {if (from > to) [from, to] = [to, from];from = Math.floor(from);to = Math.floor(to);return Math.floor((to - from) * Math.random() + from);}		



module.exports = {
	name: "math",
	alias: ["math"],
	category: "game",
	desc: "Play games math",
	isSpam: true,
	isGroup: true,
	isLimitGame: true,
	query: `\n┌─〔 Mode 〕\n├ ${Object.keys(modes).join('\n├ ')}\n└────    \ncontoh:\n%prefixmath hard\n`,
	async exec({zaa, z}) {
		  
       let mode = z.args[0].toLowerCase()
         if (!(mode in modes)) return z.reply( `\n┌─〔 Mode 〕\n├ ${Object.keys(modes).join('\n├ ')}\n└────    \ncontoh:\n${z.prefix}math hard\n`)
              let id = z.from
              if (id in math) return z.reply('Masih ada soal belum terjawab di chat ini')
              let math2 = genMath(mode);
             math[id] = [
      await z.reply(`Berapa hasil dari *${math2.str}*?\n\nTimeout: ${(math2.time / 1000).toFixed(2)} detik\nCorrect answer bonus: $${math2.bonus} `),
      math2, 4,
    setTimeout(async () => {
      if (math[id]) await z.reply(`*Time has run out*\n\n*Answer :* ${math2.result}`);delete math[id];
    }, math2.time)
  ]
	},
};