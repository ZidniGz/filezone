module.exports = {
  name: "ytmp4",
  alias: ["ytvideo"],
  category: "downloader",
  use: "<url>",
  query: 'need url',
  wait: true,
  isLimit: true,
  isUrl: true,
  async exec({zaa, z}){
  const extract = (z.quoted && z.quoted.q) ? generateLink(z.quoted.q) : z.q ? generateLink(z.q) : null
       if (extract) {
          const links = extract.filter(v => v.match(regex.youtube))
               if (links.length != 0) {
                    await youtube(links[0]).then(async(data) => {     
                 	let video = await data.video.auto.download()
                    let buff = await got(video,{referer: 'https://www.y2mate.com'}).buffer()
               if (buff.length > 30000000) return z.reply('has passed the delivery limit!!')
                    let quo = await z.reply(`*YOUTUBE DOWNLOAD*\n\n*Title :* ${data.title}\n*Quality :* auto\n*Durasi :* ${data.duration}\n*Size :* ${Size(buff.length)}\n\n_Media sedang Dikirimkan..._`)                   
                    zaa.sendMessage(z.from, {video: buff}, {quoted:quo})                  
                      })
              }
          }
     }
}