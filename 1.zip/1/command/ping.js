const moment = require("moment");

const ping = function (timestamp, now) {
	return moment.duration(now - moment(timestamp * 1000) ).asSeconds();
};
let timestamp = speed()
let latensi = speed() - timestamp
let p = latensi.toFixed(2).replace(0,'').replace(0,'').replace('.','')
module.exports = {
	name: "ping",
	alias: ["p", "speed"],
	category: "main",
	desc: "Bot response in second.",
	isSpam: true,
	async exec({ z }) {
//	return zaa
		await z.reply(`Pong!\nCPU Speed: *${p}ms*\nSpeed: *${ping(z.timestamp, Date.now())}s*`);
		
	},
};
