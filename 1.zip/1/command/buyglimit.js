module.exports = {
	name: "buyglimit",
	category: "bank",
	isSpam: true,
	use: "<amount>",
	query: "Send an order *#buyglimit* the limit amount you want to buy\n\nPrice for 1 game limit = $150 balance",
	async exec({ z, zaa }) {
		if (z.q.includes("-")) return z.reply(`Don't use -`)
		if (isNaN(z.q)) return z.reply(`Must be a number`)
		let ane = Number(Math.floor(z.q) * 150);
		if (getBalance(z.sender, balance) < ane) return z.reply(`Balance kamu tidak mencukupi untuk pembelian ini`);
		kurangBalance(z.sender, ane, balance);
		givegame(z.sender, Math.floor(z.q), glimit);
		await z.reply(
			`Purchase of game limit of ${z.q} was successful\n\nRemaining balance : $${getBalance(
				z.sender,
				balance
			)}\nRemaining Game Limit : ${cekGLimit(z.sender, gcount, glimit)}/${gcount}`
		);
	},
};
