module.exports = {
	name: "family100",
	alias: ["family100"],
	category: "game",
	desc: "Play games family100",
	isSpam: true,
	isGroup: true,
	isLimitGame: true,
    async exec({zaa, z}) {
		  
       let winScore = 5
       let id = z.from
           if (id in family) return z.reply('Masih ada kuis yang belum terjawab di chat ini')
          let src = await got('https://raw.githubusercontent.com/BochilTeam/database/master/games/family100.json').json()
          let json = src[Math.floor(Math.random() * src.length)]
          let caption = `\n*Question:* ${json.soal}\n\nTerdapat *${json.jawaban.length}* jawaban${json.jawaban.find(v => v.includes(' ')) ? `\n(beberapa jawaban terdapat spasi)\n`: ''}\n+$${winScore} tiap jawaban benar\n`.trim()
      family[id] = {
             id,
      msg: await z.reply(caption),
       ...json,
      terjawab: Array.from(json.jawaban, () => false),
      winScore,
};
	},
};
