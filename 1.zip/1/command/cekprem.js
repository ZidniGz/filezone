module.exports = {
	name: "cekpremium",
	alias: ["cekprem", "cekvip"],
	category: "premium",
	isSpam: true,
	isPremium: true,
	async exec({ z }) {
		let cekvip = uptime((await prem.getPremiumExpired(z.sender, premium)) - Date.now());
		let premiumnya = `*Expired :* ${cekvip}`;
		z.reply(premiumnya);
	},
};
