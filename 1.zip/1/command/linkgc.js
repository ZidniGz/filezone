let { areJidsSameUser } = require("baileys")

module.exports = {
  name: "linkgroup",
  alias: ["linkgc","linkgroup","grouplink"],
  category: "group",
  desc: "Get link group",
  async exec({z, zaa}) {
    let group = z.from
    if (/^[0-9]{5,16}-?[0-9]+@g\.us$/.test(z.args[0])) group = z.args[0]
    if (!/^[0-9]{5,16}-?[0-9]+@g\.us$/.test(group)) throw 'Hanya bisa untuk id grup'
    let groupMetadata = await zaa.groupMetadata(group)
    if (!groupMetadata) throw 'groupMetadata is undefined :\\'
    if (!('participants' in groupMetadata)) throw 'participants is not defined :('
    let me = groupMetadata.participants.find(user => areJidsSameUser(user.id, zaa.user.id))
    if (!me) throw 'Aku tidak ada di grup itu :('
    if (!me.admin) throw 'Aku bukan admin T_T'
    let idnya = await zaa.groupInviteCode(group)
    z.reply('https://chat.whatsapp.com/' + idnya, {adReply : true, title:groupMetadata.subject, url: `https://chat.whatsapp.com/${idnya}`})
  }
}