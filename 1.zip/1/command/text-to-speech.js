module.exports = {
	name: "tts",
	alias: ['ts','tts'],
	desc: "membuat suara dari teks",
	category: "tools",
	query: "Use example #tts id hallo dunia",
	isSpam: true,
    async exec({ z, zaa }) {
	const gtts = require('node-gtts')
function tts(text, lang = 'id') {
  return new Promise((resolve, reject) => {
    try {
      let tts = gtts(lang)
      let filePath =  (1 * new Date) + '.mp3'
      tts.save(filePath, text, () => {
        resolve(fs.readFileSync(filePath))
        fs.unlinkSync(filePath)
				
      })
    } catch (e) { reject(e) }
  })
}    

const defaultLang = 'id'


  let lang = z.args[0]
  let text = z.args.slice(1).join(' ')
  if ((z.args[0] || '').length !== 2) {
    lang = defaultLang
    text = z.args.join(' ')
  }
  if (!text && z.quoted?.body) text = z.quoted.body

  let ras
  try { ras = await tts(text, lang) }
  catch (e) {
    return z.reply(e + '')
    text = z.args.join(' ')
    ras = await tts(text, defaultLang)
  } finally {
    if (ras) 
    zaa.sendMessage(z.from, {audio: ras,ptt: true, waveform:  [0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  9,35, 51, 67, 73, 73, 25, 18, 58, 75, 72, 26,  0,27, 56, 58, 43, 12, 23, 35, 49, 62, 67, 63, 18,2, 16, 39, 45, 43, 31, 21, 36, 57, 71, 70, 67,23, 49, 36,  6, 17, 39, 50, 52, 45, 27, 26, 50,51, 49, 49, 49], mimetype: 'audio/mpeg'}, {quoted: z }) 
  }
	},
};
