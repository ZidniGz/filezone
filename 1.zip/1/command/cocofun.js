module.exports = {
  name: "cocofun",
  alias: ["ccf"],
  category: "downloader",
  use: "<url>",
  query: 'need url',
  wait: true,
  isUrl: true,
  isLimit: true,
  async exec({zaa, z}){
  const extract = (z.quoted && z.quoted.q) ? generateLink(z.quoted.q) : z.q ? generateLink(z.q) : null
       if (extract) {
          const links = extract.filter(v => v.match(regex.cocofun))
               if (links.length != 0) {
                    await cocofun(links[0]).then(data=> {
                  z.sendFile(z.from, data.url, '', data.title);
                         })                                   
                    }
          }
  }
}
