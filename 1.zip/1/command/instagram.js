module.exports = {
    name: "instagram",
	alias: ["ig","igdl","igs","igstory"],
	category: "downloader",
	query: "need url",
	use: "<url>",
	isLimit: true,
	wait: true,
	isUrl: true,
	async exec({z,zaa}){
	  			  const extract = (z.quoted && z.quoted.q) ? generateLink(z.quoted.q) : z.q ? generateLink(z.q) : null
       if (extract) {
          const links = extract.filter(v => igFixed(v).match(regex.instagram))
               if (links.length != 0) {
                  z.reply(response.wait)          
                  await instagram(igFixed(links[0])).then(data=> {
             for ( let i of data ) {
         if (i.type === "video") {
                 zaa.sendMessage(z.from, {caption: `Instagram Download`,video: {url: i.url}}, {quoted: z })
       } else if (i.type === "image") {
                 zaa.sendMessage(z.from, { caption: `Instagram Download`, image: { url: i.url }}, {quoted: z})
            }
     }
             })     
           }
          }
	}
}
