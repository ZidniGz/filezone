module.exports = {
	name: "whatmusic",
	alias: ["wmusic", "whatmusik", "wmusik"],
	category: "search",
	use: "<reply audio>",
	isSpam: true,
	wait: true,
	isLimit:true,
	isMedia: { isQVideo: true, isQAudio: true },
	desc: "Search for song titles through music or voice",
	async exec({ z, zaa }) {
	let buffer = z.quoted ? await z.quoted.download() : await z.download();
    	let { status, metadata } = await whatmusic(buffer)
		if (status.code !== 0) return z.reply(status.msg)
		let { title, artists, album, genres, release_date, external_metadata , duration_ms, score} = metadata.music[0]
		let txt = `*• Title :* ${title}${artists ? `\n*• Artists :* ${artists.map(v => v.name).join(', ')}` : ''}`
		txt += `${album ? `\n*• Album :* ${album.name}` : ''}${genres ? `\n*• Genres :* ${genres.map(v => v.name).join(', ')}` : ''}\n`
		txt += `*• Duration :* ${konversiMilidetikKeWaktu(duration_ms)}\n`
		txt += `*• Release Date :* ${release_date}\n`
		txt += `*• Score :* ${score}\n${external_metadata.youtube ? `*• Source :* https://youtu.be/${external_metadata.youtube.vid}\n\n\n` : ''}`
        let quo = zaa.sendMessage(z.from, { text: txt.trim() }, { quoted: z })
	    if (external_metadata.youtube) {
	         let data = await youtube(`https://youtu.be/${external_metadata.youtube.vid}`).catch(_ => false)
               if (data) {
                let video = await data.audio['128kbps'].download()
                let buff = await got(video,{referer: 'https://www.y2mate.com'}).buffer()
                zaa.sendMessage(z.from, {audio: buff, mimetype: 'audio/mpeg'}, {quoted:z});           
             } else {
               const data2 = await ytMusic(title)
              if (!data2) return;
              const { url } = data2.getRandom();
              const { audio } = await youtube(url)                
              let video = await audio['128kbps'].download()
              let buff = await got(video,{referer: 'https://www.y2mate.com'}).buffer()
              zaa.sendMessage(z.from, {audio: buff, mimetype: 'audio/mpeg'}, {quoted:z});        
	   }
	 }
	},
};
function konversiMilidetikKeWaktu(milidetik) {
    // Konversi milidetik ke detik
    let detik = milidetik / 1000;

    // Hitung menit dan sisa detik
    let menit = Math.floor(detik / 60);
    detik = Math.floor(detik % 60);

    let waktu = `${menit}:${detik.toString().padStart(2, '0')}`;

    return waktu;
}