const fs = require("fs")

module.exports = {
  name: "afk",
  alias: ["afk"],
  category: "main",
  use: " <reason>",
  desc: "Away from Keyboard",
  isGroup: true,
  async exec({zaa, z}) {    
      const afk = JSON.parse(fs.readFileSync("./database/afk.json"));
      afk[z.sender] = {
        id: z.sender,
        time: Date.now(),
        reason: z.q ? z.q : "Nothing",
      }
      await fs.writeFileSync("./database/afk.json", JSON.stringify(afk));
      txt = "*AFK MODE*\n\n"
      txt += z.pushName + " is now Afk!!\n"
      txt += `Reason : ${z.q ? z.q : "Nothing"}`
      z.reply(txt)
    }
}
